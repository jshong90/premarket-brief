import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const dist=path.join(root,'dist');
const files=['index.html','premarket.html'];
for(const filename of files){
  let html=fs.readFileSync(path.join(dist,filename),'utf8');
  html=html.replace(/<script type="module" crossorigin src="\.\/([^"]+)"><\/script>/g,(_,file)=>'<script type="module">'+fs.readFileSync(path.join(dist,file),'utf8').replaceAll('</script','<\\/script')+'</script>');
  html=html.replace(/<link rel="stylesheet" crossorigin href="\.\/([^"]+)">/g,(_,file)=>'<style>'+fs.readFileSync(path.join(dist,file),'utf8')+'</style>');
  html=html.replace(/href="\.\/assets\/favicon-[^"]+"/g,'href="data:image/svg+xml,'+encodeURIComponent(fs.readFileSync(path.join(root,'favicon.svg'),'utf8'))+'"');
  fs.writeFileSync(path.resolve(root,'../',filename),html);
}
for(const asset of fs.readdirSync(path.join(dist,'assets'))){if(asset.endsWith('.js'))fs.copyFileSync(path.join(dist,'assets',asset),path.resolve(root,'..',asset));}
fs.cpSync(path.join(dist,'data'),path.resolve(root,'../data'),{recursive:true});
console.log('Updated standalone index.html, premarket.html, and snapshot data');
